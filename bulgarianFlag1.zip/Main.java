
//this program should draw a bulgarian flag. The top third of the canvas is white, the second third of the canvas is green, and the last third of the canvas is red 

import javax.swing.*; //For JFrame and JPanel
import java.awt.*;
//For Color, Container, and GridLayout

class Main {
  public static void main(String[] args) {
    JFrame theGUI = new JFrame();
    theGUI.setTitle("Bulgarian Flag");
    theGUI.setSize(300, 200);
    theGUI.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    JPanel panel1 = new JPanel();
    panel1.setBackground(Color.white);
    JPanel panel2 = new JPanel();
    panel2.setBackground(Color.white);
    JPanel panel3 = new JPanel();
    panel3.setBackground(Color.white);
    JPanel panel4 = new JPanel();
    panel4.setBackground(Color.green);
    JPanel panel5 = new JPanel();
    panel5.setBackground(Color.green);
    JPanel panel6 = new JPanel();
    panel6.setBackground(Color.green);
    JPanel panel7 = new JPanel();
    panel7.setBackground(Color.red);
    JPanel panel8 = new JPanel();
    panel8.setBackground(Color.red);
    JPanel panel9 = new JPanel();
    panel9.setBackground(Color.red);
    Container pane = theGUI.getContentPane();
    pane.setLayout(new GridLayout(3, 3));
    pane.add(panel1);
    pane.add(panel2);
    pane.add(panel3);
    pane.add(panel4);
    pane.add(panel5);
    pane.add(panel6);
    pane.add(panel7);
    pane.add(panel8);
    pane.add(panel9);
    theGUI.setVisible(true);

  }
}